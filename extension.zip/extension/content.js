let overlayElement = null;
let countdownTimer = null;
let currentCountdown = 0;
let liveScreenInterval = null;

function createOverlay(data) {
  if (overlayElement) return;

  const quote = data.quote || 'Focus is the bridge between goals and achievements.';
  const message = data.message || 'YouTube access is restricted by your school during class.';
  currentCountdown = Number(data.countdownSeconds || 0);

  overlayElement = document.createElement('div');
  overlayElement.id = 'blockscroll-overlay';
  overlayElement.innerHTML = `
    <div class="bs-blur"></div>
    <div class="bs-card">
      <div class="bs-logo">BlockScroll</div>
      <h1>Return to Study</h1>
      <p class="bs-message">${message}</p>
      <p class="bs-quote">"${quote}"</p>
      <div class="bs-timer" id="bs-timer">${currentCountdown > 0 ? `Retry in ${currentCountdown}s` : 'Please follow teacher instructions'}</div>
    </div>
  `;

  document.documentElement.appendChild(overlayElement);
  document.body.classList.add('bs-locked');

  if (currentCountdown > 0) {
    countdownTimer = setInterval(() => {
      currentCountdown -= 1;
      const timerEl = document.getElementById('bs-timer');
      if (timerEl) {
        timerEl.textContent =
          currentCountdown > 0 ? `Retry in ${currentCountdown}s` : 'Please follow teacher instructions';
      }
      if (currentCountdown <= 0) clearInterval(countdownTimer);
    }, 1000);
  }

  document.querySelectorAll('video').forEach((v) => v.pause());
}

function removeOverlay() {
  if (countdownTimer) clearInterval(countdownTimer);
  countdownTimer = null;
  if (overlayElement?.parentNode) overlayElement.parentNode.removeChild(overlayElement);
  overlayElement = null;
  document.body.classList.remove('bs-locked');
}

function isOnYoutube() {
  return /youtube\.com/.test(window.location.hostname);
}

function sendActivity() {
  chrome.runtime.sendMessage({
    type: 'STUDENT_ACTIVITY',
    payload: {
      url: window.location.href,
      title: document.title,
      isOnYoutube: isOnYoutube()
    }
  });
}

function sendScreenshotFrame() {
  try {
    const video = document.querySelector('video');
    if (!video || video.readyState < 2) return;
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(320, Math.floor(video.videoWidth * 0.35));
    canvas.height = Math.max(180, Math.floor(video.videoHeight * 0.35));
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const imageData = canvas.toDataURL('image/jpeg', 0.55);
    chrome.runtime.sendMessage({ type: 'STUDENT_SCREENSHOT', payload: { imageData } });
  } catch (_err) {
    // Cross-origin media or permission limitations may block frame extraction.
  }
}

function toggleLiveScreen(enabled) {
  if (enabled) {
    if (liveScreenInterval) return;
    liveScreenInterval = setInterval(sendScreenshotFrame, 1400);
    sendScreenshotFrame();
    return;
  }
  if (liveScreenInterval) clearInterval(liveScreenInterval);
  liveScreenInterval = null;
}

function showTeacherMessage(text) {
  const existing = document.getElementById('blockscroll-msg-pop');
  if (existing) existing.remove();

  const wrap = document.createElement('div');
  wrap.id = 'blockscroll-msg-pop';
  wrap.className = 'bs-msg-pop';
  wrap.innerHTML = `
    <div class="bs-msg-pop__hd">
      <span class="bs-msg-pop__title">Message from your teacher</span>
      <button type="button" class="bs-msg-pop__x" aria-label="Dismiss">&times;</button>
    </div>
    <p class="bs-msg-pop__body"></p>
  `;
  const body = wrap.querySelector('.bs-msg-pop__body');
  body.textContent = text;

  const close = () => {
    wrap.classList.add('bs-msg-pop--out');
    setTimeout(() => wrap.remove(), 220);
  };

  wrap.querySelector('.bs-msg-pop__x').addEventListener('click', close);
  setTimeout(close, 14000);

  document.body.appendChild(wrap);
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'ADMIN_BLOCK') {
    const p = msg.payload;
    if (p?.blocked) createOverlay(p);
    else removeOverlay();
  }
  if (msg.type === 'ADMIN_ANNOUNCEMENT' && msg.data?.message) {
    showTeacherMessage(msg.data.message);
  }
  if (msg.type === 'ADMIN_LIVE_SCREEN') {
    toggleLiveScreen(Boolean(msg.data?.enabled));
  }
});

sendActivity();
setInterval(sendActivity, 6000);

let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    sendActivity();
  }
}).observe(document, { subtree: true, childList: true });
