/* global io */
// Socket.IO client (UMD) loaded via importScripts — keeps one connection so the lab dashboard sees the device as soon as the extension is installed/enabled.
importScripts('socket.io.min.js');

const DEFAULTS = {
  apiUrl: 'http://localhost:3001',
  extensionKey: 'school-lab-key',
  screenshotEnabled: false,
  deviceName: 'School lab computer'
};

let socket = null;

function storageGet(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, resolve);
  });
}

function storageSet(obj) {
  return new Promise((resolve) => {
    chrome.storage.local.set(obj, resolve);
  });
}

async function loadConfig() {
  const stored = await storageGet(Object.keys(DEFAULTS));
  return { ...DEFAULTS, ...stored };
}

async function getOrCreateDeviceId() {
  const key = 'blockscroll_device_id';
  const data = await storageGet([key]);
  if (data[key]) return data[key];
  const id = `LAB-${Math.random().toString(36).slice(2, 10).toUpperCase()}`;
  await storageSet({ [key]: id });
  return id;
}

async function emitStudentIdentify() {
  if (!socket || !socket.connected) return;
  const cfg = await loadConfig();
  const deviceId = await getOrCreateDeviceId();
  socket.emit('client:identify', {
    role: 'student',
    extensionKey: cfg.extensionKey,
    deviceId,
    deviceName: cfg.deviceName,
    screenshotEnabled: Boolean(cfg.screenshotEnabled)
  });
}

function forwardToYoutubeTabs(message) {
  chrome.tabs.query({ url: ['*://*.youtube.com/*'] }, (tabs) => {
    (tabs || []).forEach((tab) => {
      if (tab.id == null) return;
      chrome.tabs.sendMessage(tab.id, message).catch(() => {});
    });
  });
}

function disconnectSocket() {
  if (socket) {
    try {
      socket.disconnect();
    } catch (_) {
      /* ignore */
    }
    socket = null;
  }
}

async function connectSocket() {
  const cfg = await loadConfig();
  disconnectSocket();

  socket = io(cfg.apiUrl, {
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelay: 1200,
    transports: ['websocket', 'polling']
  });

  socket.on('connect', async () => {
    await emitStudentIdentify();
    socket.emit('student:activity', {
      url: 'extension://connected',
      title: 'BlockScroll extension active',
      isOnYoutube: false
    });
  });

  socket.on('admin:block', (payload) => {
    forwardToYoutubeTabs({ type: 'ADMIN_BLOCK', payload });
  });

  socket.on('admin:announcement', (data) => {
    forwardToYoutubeTabs({ type: 'ADMIN_ANNOUNCEMENT', data });
  });

  socket.on('admin:liveScreen', (data) => {
    forwardToYoutubeTabs({ type: 'ADMIN_LIVE_SCREEN', data });
  });

  socket.on('admin:setDeviceName', async (data) => {
    if (!data?.deviceName) return;
    await storageSet({ deviceName: String(data.deviceName).slice(0, 80) });
    await emitStudentIdentify();
    socket.emit('student:activity', {
      url: 'extension://rename',
      title: 'BlockScroll extension active',
      isOnYoutube: false
    });
  });
}

async function ensureDefaultsThenConnect() {
  const cur = await storageGet(Object.keys(DEFAULTS));
  await storageSet({ ...DEFAULTS, ...cur });
  connectSocket();
}

chrome.runtime.onInstalled.addListener(() => {
  ensureDefaultsThenConnect();
});

chrome.runtime.onStartup.addListener(() => {
  ensureDefaultsThenConnect();
});

// Wake + heartbeat so the service worker reconnects after sleep
chrome.alarms.create('blockscroll-ping', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'blockscroll-ping') {
    if (!socket || !socket.connected) {
      connectSocket();
    } else {
      socket.emit('student:activity', {
        url: 'extension://heartbeat',
        title: 'BlockScroll extension active',
        isOnYoutube: false
      });
    }
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'GET_CONFIG') {
    loadConfig().then((config) => sendResponse({ ok: true, config }));
    return true;
  }
  if (message.type === 'STUDENT_ACTIVITY') {
    if (socket && socket.connected) {
      socket.emit('student:activity', message.payload);
    }
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === 'STUDENT_SCREENSHOT') {
    if (socket && socket.connected) {
      socket.emit('student:screenshot', message.payload);
    }
    sendResponse({ ok: true });
    return false;
  }
  return false;
});

ensureDefaultsThenConnect();
